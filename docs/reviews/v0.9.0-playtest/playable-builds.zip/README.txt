# 拾光港 · LoopSeed 双版本试玩

解压后，在浏览器中打开三个目录里的 index.html。seed 是两次模型运行共同的起点，其余两份是模型实际交付的 HTML。游戏离线可玩。为独立体验两份存档，可使用不同的浏览器配置文件。

Open each index.html locally. Use separate browser profiles for fresh saves. Both model outputs are preserved as played.

SHA-256

3d591b58c8d5ae8d7a32875a37083f5486f7b078ec9bf9106bcb29f23e5f3885  seed/index.html
e5c75087ff3a888974cd1ba18efa3a414d1acc42675f1c45510980366c36da45  v0.8.1/index.html
afecd5827e1d789216c1441d212bf5cb3c4b908b09a856db332c47e682f7f911  v0.9.0/index.html
